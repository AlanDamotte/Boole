package jus.aoo.boole.composant;

public interface _Composant {
	
}