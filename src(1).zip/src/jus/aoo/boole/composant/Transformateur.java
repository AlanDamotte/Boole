package jus.aoo.boole.composant;

public abstract class Transformateur implements _Composant {

}
