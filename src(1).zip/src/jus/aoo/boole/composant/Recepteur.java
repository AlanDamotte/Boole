package jus.aoo.boole.composant;

public abstract class Recepteur implements _Composant {

}
