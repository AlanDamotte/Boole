package jus.aoo.boole.composant;

public abstract class Generateur implements _Composant {

}
