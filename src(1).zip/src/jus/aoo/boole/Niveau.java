package jus.aoo.boole;

public enum Niveau {
	Haut, Bas;
}
