package jus.aoo.boole;

import jus.aoo.boole.composant._Composant;

public class Circuit {
	
	private int num_composant;
	private String nom;
	
	public void ajoute_composant(_Composant composant){
		
	}
	
	
}
