package jus.aoo.boole.port;

public class Entree implements _Port<???> {

}
