package jus.aoo.boole.port;

public class Sortie implements _Port<LISTE>{

}
