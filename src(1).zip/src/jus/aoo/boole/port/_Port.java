package jus.aoo.boole.port;

public interface _Port<T> {
	
	public boolean est_connecte();
	
}
